				Set pagesize 0
				Set long 90000
				Set feedback off
				Set echo off
				Set heading off
				Set lines 100
				Select
   				DBMS_Metadata.Get_DDL('TRIGGER',t.trigger_name,t.owner)
				From
   				DBA_Triggers t
				Where
   				Triggering_Event in ('LOGON ', 'LOGOFF ');
