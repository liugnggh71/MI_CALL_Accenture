echo exit | /u02/app/oracle/product/12.1.0/dbhome_3/bin/sqlplus "/as sysdba" @/u02/opt/oracle.tfa/oracle.ahf/tfa/resources/sql/srdc_statsadvisor_report.sql
