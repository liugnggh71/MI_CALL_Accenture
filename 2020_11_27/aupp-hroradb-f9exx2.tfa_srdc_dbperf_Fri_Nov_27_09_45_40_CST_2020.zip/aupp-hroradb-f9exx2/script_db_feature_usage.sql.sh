/u02/app/oracle/product/12.1.0/dbhome_3/bin/sqlplus "/as sysdba" << EOF1
@/u02/opt/oracle.tfa/oracle.ahf/tfa/resources/sql/db_feature_usage.sql

EOF1
